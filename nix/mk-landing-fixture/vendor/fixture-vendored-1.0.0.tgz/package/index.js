module.exports = "vendored";
